Données mises à jour
